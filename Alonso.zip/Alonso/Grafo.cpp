#include "Grafo.h"

using namespace std;

Grafo::Grafo(){}

Grafo::Grafo(int n1){
	n = n1;
	lista_vertices = new Vertice*[n];
	for (int i=0; i<lista_allArestas.size(); i++){
		particao[i] = 0; /*inicialmente opcional*/
	}
}


void Grafo::setN(int n1){
	n = n1;
	lista_vertices = new Vertice*[n];
	for (int i=0; i<lista_allArestas.size(); i++){
		particao[i] = 0; /*inicialmente opcional*/
	}
}


void Grafo::addVertice(int id){
	Vertice *novo = new Vertice(id);
	lista_vertices[id] = novo; /*PADR�O: A faixa de id's dos v�rtices � de 0 at� n-1*/
}

Vertice *Grafo::getVertice(int id){
	return lista_vertices[id]; 		
}

Aresta *Grafo::addAresta(int id, int origem, int destino, float peso1, float peso2){
	Aresta *nova = new Aresta(id, origem, destino, peso1, peso2);
	//lista_allArestas.push_back(nova); /*deve ser passado o ponteiro, isto �, a refer�ncia*/
	lista_allArestas[id] = nova;
	lista_vertices[origem]->adicionaAresta(nova);
	lista_vertices[destino]->adicionaAresta(nova);
	return nova;
}
Aresta *Grafo::addArestaDirecionada(int id, int origem, int destino){
	Aresta *nova = new Aresta(id, origem, destino, 0,0);
	lista_allArestas[id] = nova;
	lista_vertices[origem]->adicionaAresta(nova); // aresta sai da oriem
	lista_vertices[origem]->incrementaGrau_saida();
	lista_vertices[destino]->incrementaGrau_chegada();
	return nova;
}

map <int, Aresta *> Grafo::get_allArestas(){ /*retorna a primeira posi��o do vetor lista_allArestas*/
	return lista_allArestas;
}

int Grafo::getQuantArestas(){
	return lista_allArestas.size();
}

int Grafo::getQuantVertices(){	
	return n;	
}
Aresta ** Grafo::getAllArestasPtr(){
	Aresta **arestasPtr = new Aresta*[lista_allArestas.size()];
	for (int i=0; i<lista_allArestas.size(); i++){
		arestasPtr[i] = lista_allArestas[i];
	}
	return arestasPtr;
}

int Grafo::getStatus(int i){
	return particao[i];
}
void Grafo::setStatus(int i, int valor){
	particao[i] = valor;
}
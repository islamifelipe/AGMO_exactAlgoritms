#ifndef _KRUSKAL_H_
#define _KRUSKAL_H_
#include "Grafo.h"


bool kruskal (Grafo *g, Aresta **listaAresta,  int  *A, float &x, float &y);

#endif